#include "CLI/CLI.h"

int main() {
    CLI cli;
    cli.run();
}